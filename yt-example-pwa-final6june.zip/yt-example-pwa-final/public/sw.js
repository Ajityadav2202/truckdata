self.addEventListener('install', function (event) {
  console.log('SW Installed');
  event.waitUntil(
    caches.open('static')
      .then(function (cache) {
        // cache.add('/');
        // cache.add('/index.html');
        // cache.add('/src/js/app.js');
        cache.addAll([
          '/',
          '/index.html',
          '/icons.html',
          '/contact.html',
          '/about.html',
          '/404.html',
          '/manager.html',
          '/services.html',
          '/js/bars.js',
          '/js/bootstrap.js',
          '/js/easing.js',
          '/js/easyResponsiveTabs.js',
          '/js/jquery-2.1.4.min.js',
          '/js/jquery.flexisel.js',
          '/js/lightbox-plus-jquery.min.js',
          '/js/mainScript.js',
          '/js/move-top.js',
          '/js/rgbSlide.min.js',
          '/js/SmoothScroll.min.js',
          '/css/Bootstrap.css',
          '/css/font-awesome.css',
          '/css/lightbox.css',
          '/css/mainStyles.css',
          '/css/style.css',
          '/src/js/app.js',
          '/src/css/app.css',
          '/src/images/pwa.jpg',
          '/src/js/map.js',
          '/src/css/header.css',
          '/src/css/new.css',
          'https://fonts.googleapis.com/css?family=Raleway:400,700',
          'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css',
          'https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js',
          'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js'


        ]);
      })
  );
});

self.addEventListener('activate', function () {
  console.log('SW Activated');
});

self.addEventListener('fetch', function(event) {
  event.respondWith(
    caches.match(event.request)
      .then(function(res) {
        if (res) {
          return res;
        } else {
          return fetch(event.request);
        }
      })
  );
});