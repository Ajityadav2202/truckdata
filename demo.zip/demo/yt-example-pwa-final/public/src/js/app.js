// var pwaCard = document.querySelector('#pwa');
// var pwaCardContent = pwaCard.querySelector('.card__content');
// var pwaCardDetails = pwaCard.querySelector('.card__details');
// var pwaCardmaps=pwaCard.querySelector('.googleMap');
// var detailsShown = false;

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js')
    .then(function() {
      console.log('SW registered');
    });
}

if ("serviceWorker" in navigator) {
  navigator.serviceWorker
    .register("./firebase-messaging-sw.js")
    .then(function(registration) {
      console.log("Registration successful, scope is:", registration.scope);
    })
    .catch(function(err) {
      console.log("Service worker registration failed, error:", err);
    });
}
